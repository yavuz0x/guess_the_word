from setuptools import setup, find_packages

setup(
    name='guess_the_word',
    version='1.0.0',  # Güncellendi, ilk sürüm numarasını ayarlayın
    packages=find_packages(),
    install_requires=[
        'requests',  # Versiyon belirtmeden kullanıcıya esneklik sağla
        # Diğer bağımlılıkları da buraya ekleyebilirsin
    ],
    entry_points={
        'console_scripts': [
            'guess-the-word=guess_the_word.main:main',
        ],
    },
)
